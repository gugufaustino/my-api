import { Component } from '@angular/core';

@Component({
  selector: 'produto-app-root',
  template: '<router-outlet></router-outlet>'
})
export class ProdutoAppComponent {  }
