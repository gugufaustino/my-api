import { Component } from '@angular/core';

@Component({
  selector: 'fornecedor-app-root',
  template: '<router-outlet></router-outlet>'
})
export class FornecedorAppComponent { }
